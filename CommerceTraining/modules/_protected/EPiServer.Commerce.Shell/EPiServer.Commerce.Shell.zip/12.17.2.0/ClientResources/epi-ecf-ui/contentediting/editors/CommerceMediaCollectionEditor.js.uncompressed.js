﻿define("epi-ecf-ui/contentediting/editors/CommerceMediaCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/topic",

    // EPi Framework
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/dnd/Target",


    // epi cms
    "epi-cms/contentediting/editors/CollectionEditor",
    "epi-cms/contentediting/editors/_TextWithActionLinksMixin",

    // epi commerce
    "./_GridWithDropContainerMixin",
    "./model/CommerceMediaCollectionEditorModel",
    "epi-ecf-ui/component/CommerceMediaItemModel",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.commercemediacollectioneditor"

],
function (
    //dojo
    declare,
    lang,
    aspect,
    domClass,
    domStyle,
    topic,

    // EPi Framework
    _FocusableMixin,
    Target,

    // epi cms
    CollectionEditor,
    _TextWithActionLinksMixin,

    // epi commerce
    _GridWithDropContainerMixin,
    CommerceMediaCollectionEditorModel,
    CommerceMediaItemModel,

    // Resources
    res
) {
    return declare([CollectionEditor, _GridWithDropContainerMixin, _FocusableMixin], {
        // module:
        //      epi-ecf-ui/contentediting/editors/commercemediacollectioneditor
        // summary:
        //      Editor widget for commerce media assets

        resources: res,

        _noDataMessage: '<span><span class="dijitReset dijitInline">' + res.nodatamessage + '</span></span>',

        // itemModelType: Function
        //      Item Model constructor.
        itemModelType: CommerceMediaItemModel,

        modelType: CommerceMediaCollectionEditorModel,

        //  defaultAssetGroupName: string
        //      Value provided from server that specifies a default group name for assets.
        defaultAssetGroupName: null,

        // Set autofocus to false to prevent the validate the require fields when opening dialog.
        dialogParams: { autofocus: false },

        _setupGrid: function () {
            // summary:
            //      Set up the grid.
            // tags:
            //      protected

            this.inherited(arguments);
            domClass.add(this.gridNode, "epi-plain-grid--margin-bottom epi-plain-grid--cell-borders");
            this.model.defaultAssetGroupName = this.defaultAssetGroupName;
            this._settingReadOnlyState();
        },

        postCreate: function () {
            // summary:
            //      Post create initialization.
            // description:
            //      Setup related components.
            // tags:
            //      protected

            this.gridSettings.cellNavigation = false;

            this.inherited(arguments);

            domClass.add(this.domNode, "epi-media-collection");
        },

        // Override CollectionEditor.onDndDrop to call this.grid.focus() instead of this.onFocus(), to fix the issue where onBlur event does not fire when
        // the Editor lost focus.
        // TODO remove this function after bug 121239 is fixed.
        onDndDrop: function (dndData, source, nodes, copy) {
            var i;

            // internal move
            if (this.grid.dndSource === source) {
                this.inherited(arguments);
            } else { // external drop
                // Set focus to mark start editing
                // make sure editor will be marked as start-editing immediately by invoking onDropping
                // to fix an issue in IE9, which was caused by the race condition,
                // which would lead to a problem of auto save.
                this.onDropping && this.onDropping();
                this.grid.focus();

                for (i = 0; i < dndData.length; i++) {
                    this._addItem(dndData[i]);

                    // Remove from source?
                    // TODO: Simplify
                    if (source && source.grid && source.grid.consumer && source.grid.consumer !== this) {
                        source.grid.consumer.model.removeItem(this.grid.dndSource.getItem(nodes[i].id).data);
                    }
                }
            }
        },

        _settingReadOnlyState: function () {
            if (this.readOnly) {
                // For dnd
                domStyle.set(this.dropContainer, "display", "none");
                domClass.remove(this.overlayDnd, this.gridOverlayClass);

                // For grid
                this.grid.set("selectionMode", "none");
                this.allowedDndTypes = [];
                this.gridSettings.dndDisabled = true;
                this.model.availableCommands = 0;
            }
        },

        _getDialogTitleText: function(existingItem){
            return !existingItem ? res.addlabel : res.editlabel;
        },

        _getGridDefinition: function () {
            // summary:
            //      Returns grid's columns definition.
            // tags:
            //      private

            var columns = this.generateColumns ?
                this.model.generateColumnsDefinition(this.excludedColumns) : // If auto generate is on, ask model to compute columns definition.
                this.includedColumns || {}; // Otherwise, use configured ones.

            if (this.readOnly)
            {
                for (var columnName in columns) {
                    lang.setObject("sortable", false, columns[columnName]);
                }
            }

            return this.model.generateFormatters(columns);
        }
    });
});
