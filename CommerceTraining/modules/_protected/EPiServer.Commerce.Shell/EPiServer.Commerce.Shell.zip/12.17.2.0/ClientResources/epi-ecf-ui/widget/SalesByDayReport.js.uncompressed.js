require({cache:{
'url:epi-ecf-ui/widget/templates/SalesByDayReport.html':"﻿<div data-dojo-type=\"dijit/layout/ContentPane\" class=\"epi-list-container\">\r\n    <h1>Sales By Day Report</h1>\r\n    <div data-dojo-attach-point=\"gridNode\"></div>\r\n</div>"}});
define("epi-ecf-ui/widget/SalesByDayReport", [
    // dojo
    "dojo/_base/declare",
    "dojo/currency",
    "dojo/date/locale",
    "dojo/dom-construct",
    "dojo/when",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/layout/_LayoutWidget",
    // dgrid
    "dgrid/OnDemandGrid",
    // epi
    "epi/shell/_ContextMixin",
    "./_FullHeightContentMixin",
    //template
    "dojo/text!./templates/SalesByDayReport.html",
    // resources
    "epi/i18n!epi/cms/nls/commerce.report.salesbydayreport"
], function (
    // dojo
    declare,
    currency,
    locale,
    domConstruct,
    when,
    // dijit
    _TemplatedMixin,
    _LayoutWidget,
    // dgrid
    OnDemandGrid,
    // epi
    _ContextMixin,
    _FullHeightContentMixin,
    //template
    template,
    // resources
    reportingResources
) {
    // module:
    //      epi-ecf-ui.widget.SalesByDayReport

    return declare([_LayoutWidget, _FullHeightContentMixin, _TemplatedMixin, _ContextMixin], {
        // summary:
        //      SalesByDayReport widget.
        // tags:
        //      public

        templateString: template,

        _noDataMessage: '<span><span class="dijitReset dijitInline">' + reportingResources.nodatafound + '</span></span>',

        grid: null,

        postCreate: function () {
            this.inherited(arguments);
            this._render();
        },

        layout: function () {
            // summary:
            //      Layout the overview editor.
            // tags:
            //      overrided
            if (this.grid) {
                this.grid.resize();
                // make the content 100% height its container
                this._setHeight(this.grid.domNode);
            }
        },

        _render: function () {
            // summary:
            //      Renders sales by day report
            // tags:
            //      private

            when(this.getCurrentContext()).then(function (context) {
                var salesReportData = context.data;
                var noSymbol = " ";

                this.grid = new (declare([OnDemandGrid]))({
                    className: "epi-plain-grid",
                    noDataMessage: this._noDataMessage,
                    columns: {
                        orderCreatedDate: {
                            label: reportingResources.header.date,
                            formatter: function (date) {
                                return locale.format(new Date(date), {
                                    selector: "date",
                                    datePattern: "MMM d, yyyy"
                                });
                            }
                        },
                        market: reportingResources.header.market,
                        currency: reportingResources.header.currency,
                        numberOfOrder: reportingResources.header.numberoforders,
                        itemsOrdered: reportingResources.header.itemsordered,
                        subTotal: {
                            label: reportingResources.header.subtotal,
                            get: function (item) {
                                return currency.format(item.subTotal, { currency: item.currency, symbol: noSymbol });
                            }
                        },
                        tax: {
                            label: reportingResources.header.tax,
                            get: function (item) {
                                return currency.format(item.tax, { currency: item.currency, symbol: noSymbol });
                            }
                        },
                        shipping: {
                            label: reportingResources.header.shipping,
                            get: function (item) {
                                return currency.format(item.shipping, { currency: item.currency, symbol: noSymbol });
                            }
                        },
                        discounts: {
                            label: reportingResources.header.discounts,
                            get: function (item) {
                                return currency.format(item.discounts, { currency: item.currency, symbol: noSymbol });
                            }
                        },
                        total: {
                            label: reportingResources.header.total,
                            get: function (item) {
                                return currency.format(item.total, { currency: item.currency, symbol: noSymbol });
                            }
                        }
                    }
                });
                this.grid.renderArray(salesReportData);
                domConstruct.place(this.grid.domNode, this.gridNode);
                this.own(this.grid);
            }.bind(this));
        }
   });
});