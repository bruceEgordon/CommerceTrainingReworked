﻿define("epi-ecf-ui/contentediting/editors/VariantCollectionEditor", [
    // dojo
    "dojo/_base/declare",
     // EPi Framework
    "epi/shell/widget/_FocusableMixin",
    // epi-cms
    "epi-cms/contentediting/editors/model/CollectionEditorModel",
    // ecf-ui
    "./_RelationCollectionEditorBase",
    "../viewmodel/VariantCollectionEditorModel",
    "../ModelSupport",
    
    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.variantcollectioneditor"
],
function (
    //dojo
    declare,
     // EPi Framework
     _FocusableMixin,
    // epi-cms
    CollectionEditorModel,
    // ecf-ui
    _RelationCollectionEditorBase,
    VariantCollectionEditorModel,
    ModelSupport,
    
    // Resources
    resources
) {
    return declare([_RelationCollectionEditorBase, _FocusableMixin], {
        // module:
        //      epi-ecf-ui/contentediting/editors/VariantCollectionEditEditor
        // summary:
        //      Represents the variant editable collection
                
        modelType: VariantCollectionEditorModel,

        allowedDndTypes: [ModelSupport.contentTypeIdentifier.variationContent, ModelSupport.contentTypeIdentifier.productContent, ModelSupport.linkTypeIdentifier.relation],

        itemEditorTypes: [ModelSupport.contentTypeIdentifier.variationContent, ModelSupport.contentTypeIdentifier.productContent],
        
        resources: resources,

        relationType: ModelSupport.relationType.productVariation
    });
});
